@extends('mitra.layout_mitra')
@section('content')
    <div class="page-wrapper">

        
    </div>
</div>
@endsection
